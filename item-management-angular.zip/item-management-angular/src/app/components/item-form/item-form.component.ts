import { Component, OnInit } from '@angular/core';
import { ItemService } from '../../services/item.service';
import { Item } from '../../models/item';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.css']
})
export class ItemFormComponent implements OnInit {
  item: Item = { name: '', description: '', price: 0 };
  isEditMode = false;

  constructor(
    private itemService: ItemService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.itemService.getItem(id).subscribe((data) => {
        this.item = data;
      });
    }
  }

  saveItem(): void {
    if (this.isEditMode) {
      this.itemService.updateItem(this.item.id!, this.item).subscribe(() => {
        this.router.navigate(['/items']);
      });
    } else {
      this.itemService.addItem(this.item).subscribe(() => {
        this.router.navigate(['/items']);
      });
    }
  }
  onSubmit(): void {
    if (this.isEditMode) {
      // Call the update method of the service if editing
      this.itemService.updateItem(this.item.id!, this.item).subscribe(() => {
        this.router.navigate(['/items']);
      });
    } else {
      // Call the add method of the service if creating a new item
      this.itemService.addItem(this.item).subscribe(() => {
        this.router.navigate(['/items']);
      });
    }
  }
}
